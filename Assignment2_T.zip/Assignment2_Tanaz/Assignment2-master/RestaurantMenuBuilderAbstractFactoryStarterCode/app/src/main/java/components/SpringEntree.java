package components;

public class SpringEntree implements Entree {
    @Override
    public String getName() {
        return "Lobster Veracruzana\nOrganic Ocean Halibut\nMushroom Soup";
    }
}
