package components;

public class SummerMainCourse implements MainCourse {
    @Override
    public String getName() {
        return "Beef Tartare\nSpiced Cauliflower\nChinook Salmon";
    }
}
