package components;

public class SpringDessert implements Dessert {
    @Override
    public String getName() {
        return "Vanilla Creme Brulee\nWhite Chocolate\nBrownie\nPassion Fruit Fig Tart";
    }
}

