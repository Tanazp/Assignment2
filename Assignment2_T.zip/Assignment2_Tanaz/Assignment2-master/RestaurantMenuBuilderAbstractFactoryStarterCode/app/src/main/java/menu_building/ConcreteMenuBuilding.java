/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menu_building; // Package declaration for menu building

import menu_factory.*; // Importing all classes from the menu_factory package
import menus.*; // Importing all classes from the menus package

/**
 * Concrete implementation of the MenuBuilding class for creating specific restaurant menus
 * based on the season.
 * 
 * @author patha
 */
public class ConcreteMenuBuilding extends MenuBuilding {
    
    /**
     * Creates a restaurant menu based on the specified season.
     * 
     * @param season the season for which the menu is to be built
     * @return a RestaurantMenu object corresponding to the specified season
     */
    @Override
    protected RestaurantMenu makeMenuBuilding(String season) {
        RestaurantMenu theMenu = null; // Initialize the menu to null
        
        // Create Fall menu
        if ("Fall".equalsIgnoreCase(season)) {
            RestaurantMenuFactory theFactory = new FallRestaurantMenuFactory(); // Create factory for Fall menu
            theMenu = new FallRestaurantMenu(theFactory); // Create Fall menu
            theMenu.setName("Fall Menu"); // Set the menu name
            theMenu.setPeriod("September 1 to November 30."); // Set the active period
        }
        // Create Winter menu
        else if ("Winter".equalsIgnoreCase(season)) {
            RestaurantMenuFactory theFactory = new WinterRestaurantMenuFactory(); // Create factory for Winter menu
            theMenu = new WinterRestaurantMenu(theFactory); // Create Winter menu
            theMenu.setName("Winter Menu"); // Set the menu name
            theMenu.setPeriod("December 1 to February 28."); // Set the active period
        }
        // Create Spring menu
        else if ("Spring".equalsIgnoreCase(season)) {
            RestaurantMenuFactory theFactory = new SpringRestaurantMenuFactory(); // Create factory for Spring menu
            theMenu = new SpringRestaurantMenu(theFactory); // Create Spring menu
            theMenu.setName("Spring Menu"); // Set the menu name
            theMenu.setPeriod("March 1 to May 30."); // Set the active period
        }
        // Create Summer menu
        else if ("Summer".equalsIgnoreCase(season)) {
            RestaurantMenuFactory theFactory = new SummerRestaurantMenuFactory(); // Create factory for Summer menu
            theMenu = new SummerRestaurantMenu(theFactory); // Create Summer menu
            theMenu.setName("Summer Menu"); // Set the menu name
            theMenu.setPeriod("June 1 to August 31"); // Set the active period
        }
        
        return theMenu; // Return the created menu
    }
}
