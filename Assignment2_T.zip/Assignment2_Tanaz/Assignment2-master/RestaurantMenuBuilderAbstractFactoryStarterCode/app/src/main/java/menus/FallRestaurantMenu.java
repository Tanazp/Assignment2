package menus;

// Importing the RestaurantMenuFactory from the menu_factory package
import menu_factory.RestaurantMenuFactory;

// FallRestaurantMenu class extending RestaurantMenu
public class FallRestaurantMenu extends RestaurantMenu {
    private RestaurantMenuFactory factory; // Factory for creating menu items

    // Constructor accepting a RestaurantMenuFactory object
    public FallRestaurantMenu(RestaurantMenuFactory factory) {
        this.factory = factory; // Initializing the factory
    }

    // Overriding the populateMenu method to add items to the Fall menu
    @Override
    public void populateMenu() {
        // Outputting the current action to the console
        System.out.println("Adding items to " + getName());
        
        // Setting the name and period of the menu
        setName("Fall Menu");
        setPeriod("September 1 to November 30.");
        
        // Using the factory to create menu items
        entree = factory.createEntree();
        mainCourse = factory.createMainCourse();
        dessert = factory.createDessert();
        drink = factory.createDrink();
    }
}
