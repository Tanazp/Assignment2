package components;

public class WinterMainCourse implements MainCourse {
    @Override
    public String getName() {
        return "Sirloin\nSalmon Croquettes\nSteak and Fries";
    }
}
