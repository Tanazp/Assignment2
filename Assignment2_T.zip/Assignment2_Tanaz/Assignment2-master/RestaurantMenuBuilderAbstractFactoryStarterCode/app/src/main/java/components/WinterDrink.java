package components;

public class WinterDrink implements Drink {
    @Override
    public String getName() {
        return "Mojito\nAlcohol Free Wine\nTequila";
    }
}
