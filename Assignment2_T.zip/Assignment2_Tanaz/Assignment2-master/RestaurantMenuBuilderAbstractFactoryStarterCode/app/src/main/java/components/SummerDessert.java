package components;

public class SummerDessert implements Dessert {
    @Override
    public String getName() {
        return "Lime Pie\nUltimate Cookie\nChurro Ice Cream Sandwich";
    }
}
