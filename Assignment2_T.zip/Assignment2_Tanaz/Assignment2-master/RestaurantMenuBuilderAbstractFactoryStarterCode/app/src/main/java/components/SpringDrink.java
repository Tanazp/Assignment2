package components;

public class SpringDrink implements Drink {
    @Override
    public String getName() {
        return "Cucumber Smash\nLime Juice\nCandy Apple Cider";
    }
}
