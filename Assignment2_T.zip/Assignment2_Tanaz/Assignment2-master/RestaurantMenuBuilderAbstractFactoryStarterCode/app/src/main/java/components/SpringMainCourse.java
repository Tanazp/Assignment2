package components;

public class SpringMainCourse implements MainCourse {
    @Override
    public String getName() {
        return "Sunny Rise Burger\nCalifornia Spring Salad\nCrispy Chicken\nSandwich";
    }
}
