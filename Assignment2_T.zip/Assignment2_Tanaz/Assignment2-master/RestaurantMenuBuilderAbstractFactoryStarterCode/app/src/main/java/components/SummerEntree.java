package components;

public class SummerEntree implements Entree {
    @Override
    public String getName() {
        return "Avocado scramble\nLittle Gem Salad\nMiso Cauliflower Soup";
    }
}
