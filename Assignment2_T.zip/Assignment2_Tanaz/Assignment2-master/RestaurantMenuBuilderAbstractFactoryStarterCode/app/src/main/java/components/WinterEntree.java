package components;

public class WinterEntree implements Entree {
    @Override
    public String getName() {
        return "Sesame Soy Tartare\nBoston Clam Chowder\nThai Soup";
    }
}
