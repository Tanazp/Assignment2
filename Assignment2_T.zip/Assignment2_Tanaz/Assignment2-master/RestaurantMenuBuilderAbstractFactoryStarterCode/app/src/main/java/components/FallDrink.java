package components;

public class FallDrink implements Drink {
    @Override
    public String getName() {
        return "Margarita\nDark Rum\nOrange Juice";
    }
}
