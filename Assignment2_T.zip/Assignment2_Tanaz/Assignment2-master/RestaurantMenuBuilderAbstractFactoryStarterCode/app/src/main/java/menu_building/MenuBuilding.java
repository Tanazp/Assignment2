/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menu_building; // Package declaration for menu building

import menus.*; // Importing all classes from the menus package

/**
 * Abstract class that defines the structure for building restaurant menus.
 * 
 * @author patha
 */
public abstract class MenuBuilding {

    /**
     * Abstract method for creating a restaurant menu based on the season.
     * Subclasses must implement this method to define how menus are built.
     *
     * @param season the season for which the menu is to be created
     * @return a RestaurantMenu object corresponding to the specified season
     */
    protected abstract RestaurantMenu makeMenuBuilding(String season);

    /**
     * Builds a restaurant menu by calling the makeMenuBuilding method and populating the menu.
     *
     * @param season the season for which the menu is to be built
     * @return a fully populated RestaurantMenu object
     */
    public RestaurantMenu buildRestaurantMenu(String season) {
        RestaurantMenu theMenu = makeMenuBuilding(season); // Creates a menu using the specified season
        theMenu.populateMenu(); // Populates the created menu
        return theMenu; // Returns the populated menu
    }
}
