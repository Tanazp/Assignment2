package components;

public class WinterDessert implements Dessert {
    @Override
    public String getName() {
        return "Chocolate Mousse\nCaramel Cheesecake\nChocolate Sponge Cake";
    }
}
