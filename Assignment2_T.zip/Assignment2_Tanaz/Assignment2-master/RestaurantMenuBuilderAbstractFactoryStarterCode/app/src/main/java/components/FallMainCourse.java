package components;

public class FallMainCourse implements MainCourse {
    @Override
    public String getName() {
        return "Salmon Avocado Toast\nPesto Chicken Penne Asiago\nPortobello Mushroom Chicken";
    }
}
