package components;

public class SummerDrink implements Drink {
    @Override
    public String getName() {
        return "Lemonade\nSangria\nRum Punch";
    }
}
