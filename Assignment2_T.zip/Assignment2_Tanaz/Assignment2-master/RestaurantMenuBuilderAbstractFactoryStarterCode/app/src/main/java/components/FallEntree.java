package components;

public class FallEntree implements Entree {
    @Override
    public String getName() {
        return "Spinach and Artichoke Dip\nSesame Soy Tuna Tartare\nTuscan Bruschetta";
    }
}