package components;

public class FallDessert implements Dessert {
    @Override
    public String getName() {
        return "Carrot Cake\nWhite Chocolate Cheesecake\nApple Pie";
    }
}
