package menus;

// Importing required components
import components.*;

public abstract class RestaurantMenu {
    // Class attributes
    private String name; // Name of the menu
    private String period; // Active period for the menu (e.g., seasonal)
    protected Entree entree; // The entree for the menu
    protected MainCourse mainCourse; // The main course for the menu
    protected Dessert dessert; // The dessert for the menu
    protected Drink drink; // The drink for the menu

    // Getter for the name of the menu
    public String getName() {
        return name;
    }

    // Setter for the name of the menu
    public void setName(String name) {
        this.name = name;
    }

    // Getter for the active period of the menu
    public String getPeriod() {
        return period;
    }

    // Setter for the active period of the menu
    public void setPeriod(String period) {
        this.period = period;
    }

    // Abstract method to populate the menu, must be implemented by subclasses
    public abstract void populateMenu();

    // Overriding toString method to provide a string representation of the menu
    @Override
    public String toString() {
        return "The " + name + "\nActive: " + period + "\nEntrees:\n" + entree.getName() +
               "\nMain Courses:\n" + mainCourse.getName() +
               "\nDesserts:\n" + dessert.getName() +
               "\nDrinks:\n" + drink.getName();
    }
}
